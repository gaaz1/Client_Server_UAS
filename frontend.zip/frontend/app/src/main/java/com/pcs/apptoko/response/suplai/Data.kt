package com.pcs.apptoko.response.suplai



data class Data(
    val suplai: List<Suplai>
)
